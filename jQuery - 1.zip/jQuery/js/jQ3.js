$(function() {
$("ul li:even").addClass('tlo2');
$("ul li:odd").addClass('tlo1');
});