$(function(){
    $("tr:odd").css("background","#B0B0B0");
    $("tr:even").css("background","#EEE");
});