$(function(){
    $("button").mouseover(function() {
        if($("button").hasClass("appear"))
        {
            $("button").removeClass("appear");
        }
        $("button").addClass("disapear");
    });

    $("button").mouseout(function() {
        if($("button").hasClass("disapear"))
        {
            $("button").removeClass("disapear");
        }
        $("button").addClass("appear");
    });

});