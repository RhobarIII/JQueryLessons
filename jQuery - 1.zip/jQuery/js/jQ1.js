$(function() {
$('#napis').click(function() {
$('#opis').toggle("slow")
});
});
